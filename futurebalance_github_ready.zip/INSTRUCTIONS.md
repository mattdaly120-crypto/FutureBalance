Quick start instructions
------------------------
1) Upload this folder to GitHub (create a new repo and upload).
2) In Xcode (or a cloud Mac), create a new iOS App (SwiftUI) project named FutureBalance.
3) Drag the files from Sources/ into your Xcode project, choose "Copy items if needed".
4) Add PlaidLink SDK via Swift Package Manager after importing into Xcode:
   - File -> Add Packages... -> https://github.com/plaid/plaid-link-ios
5) Add assets to Assets.xcassets as described in ASSETS_INSTRUCTIONS.txt.
6) Update PlaidService.swift baseURL to your deployed PlaidServer URL after you deploy it.
7) Deploy PlaidServer/ to Render or similar (see PlaidServer/README_DEPLOY.md).
8) Configure Codemagic to build and upload to App Store Connect using App Store Connect API key.
