import Foundation

struct LinkTokenResponse: Decodable { let link_token: String }
struct AccessTokenResponse: Decodable { let access_token: String }

class PlaidService {
    private let baseURL = "https://your-plaid-server.onrender.com" // update after deploy

    func createLinkToken(completion: @escaping (Result<String, Error>) -> Void) {
        guard let url = URL(string: "\(baseURL)/create_link_token") else { completion(.failure(NSError())); return }
        var req = URLRequest(url: url); req.httpMethod = "POST"
        URLSession.shared.dataTask(with: req) { data, _, err in
            if let e = err { return completion(.failure(e)) }
            guard let data = data else { return completion(.failure(NSError())) }
            do { let decoded = try JSONDecoder().decode(LinkTokenResponse.self, from: data); completion(.success(decoded.link_token)) } catch { completion(.failure(error)) }
        }.resume()
    }

    func exchangePublicToken(_ publicToken: String, completion: @escaping (Result<String, Error>) -> Void) {
        guard let url = URL(string: "\(baseURL)/exchange_public_token") else { completion(.failure(NSError())); return }
        var req = URLRequest(url: url); req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.httpBody = try? JSONSerialization.data(withJSONObject: ["public_token": publicToken])
        URLSession.shared.dataTask(with: req) { data, _, err in
            if let e = err { return completion(.failure(e)) }
            guard let data = data else { return completion(.failure(NSError())) }
            do { let decoded = try JSONDecoder().decode(AccessTokenResponse.self, from: data); completion(.success(decoded.access_token)) } catch { completion(.failure(error)) }
        }.resume()
    }
}
