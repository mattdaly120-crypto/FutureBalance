import SwiftUI

struct OnboardingView: View {
    var onSignedIn: () -> Void
    var body: some View {
        VStack(spacing: 24) {
            Image("appLogo").resizable().frame(width:96, height:96).renderingMode(.original)
            Text("FutureBalance").font(.largeTitle).bold()
            Text("See how your balance changes over time").font(.subheadline).multilineTextAlignment(.center)
            Button("Sign in") { onSignedIn() }
                .frame(maxWidth:.infinity).padding().background(Color.blue).foregroundColor(.white).cornerRadius(10).padding(.horizontal)
            Button(action: { onSignedIn() }) {
                HStack { Image(systemName:"applelogo"); Text("Sign in with Apple") }
            }
            .frame(maxWidth:.infinity).padding().background(Color.black).foregroundColor(.white).cornerRadius(10).padding(.horizontal)
        }.padding()
    }
}
