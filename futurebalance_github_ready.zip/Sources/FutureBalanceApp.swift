import SwiftUI

@main
struct FutureBalanceApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationView { RootView() }
        }
    }
}

struct RootView: View {
    @State private var signedIn = false
    var body: some View {
        if signedIn {
            DashboardView()
        } else {
            OnboardingView(onSignedIn: { signedIn = true })
        }
    }
}
