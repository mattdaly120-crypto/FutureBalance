import SwiftUI

class LinkAccountViewModel: ObservableObject {
    @Published var linkToken: String?
    @Published var errorMessage: String?
    private let service = PlaidService()

    func fetchLinkToken() {
        service.createLinkToken { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let token): self.linkToken = token
                case .failure(let err): self.errorMessage = err.localizedDescription
                }
            }
        }
    }

    func exchange(publicToken: String) {
        service.exchangePublicToken(publicToken) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let access): print("Got access token: \(access)")
                case .failure(let err): self.errorMessage = err.localizedDescription
                }
            }
        }
    }
}

struct LinkAccountView: View {
    @StateObject var vm = LinkAccountViewModel()
    @State private var showPlaid = false

    var body: some View {
        VStack(spacing:20) {
            if let token = vm.linkToken {
                Button("Connect Your Bank") { showPlaid = true }
                    .sheet(isPresented:$showPlaid) {
                        PlaidLinkView(linkToken: token) { publicToken in
                            vm.exchange(publicToken: publicToken)
                            showPlaid = false
                        }
                    }
            } else {
                Button("Fetch Link Token") { vm.fetchLinkToken() }
            }

            if let err = vm.errorMessage { Text("Error: \(err)").foregroundColor(.red) }
        }.padding().navigationTitle("Link Account")
    }
}
