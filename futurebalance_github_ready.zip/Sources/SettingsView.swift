import SwiftUI

struct SettingsView: View {
    var body: some View {
        Form {
            Section {
                HStack {
                    Image("profileIcon").resizable().frame(width:64,height:64).clipShape(Circle())
                    VStack(alignment:.leading) {
                        Text("John Doe").bold()
                        Text("john.doe@example.com").font(.caption).foregroundColor(.gray)
                    }
                }
            }
            Section {
                NavigationLink("Subscription", destination: Text("Subscription details"))
                Button("Sign Out", role:.destructive) { /* sign out */ }
            }
        }.navigationTitle("Settings")
    }
}
