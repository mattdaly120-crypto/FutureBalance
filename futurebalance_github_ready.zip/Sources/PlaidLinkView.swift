import SwiftUI
#if canImport(LinkKit)
import LinkKit
#endif

struct PlaidLinkView: UIViewControllerRepresentable {
    let linkToken: String
    var onSuccess: (String) -> Void

    func makeUIViewController(context: Context) -> UIViewController {
        let root = UIViewController()
        #if canImport(LinkKit)
        let configuration = LinkTokenConfiguration(token: linkToken) { success in
            onSuccess(success.publicToken)
        }
        let controller = PLKPlaidLinkViewController(configuration: configuration) { _ in }
        root.addChild(controller); root.view.addSubview(controller.view); controller.didMove(toParent: root)
        #else
        // Placeholder view when LinkKit unavailable (e.g., in editors)
        let label = UILabel()
        label.text = "Plaid Link not available; run on device with LinkKit added."
        label.numberOfLines = 0; label.textAlignment = .center
        root.view.addSubview(label); label.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([label.centerXAnchor.constraint(equalTo: root.view.centerXAnchor), label.centerYAnchor.constraint(equalTo: root.view.centerYAnchor), label.leadingAnchor.constraint(equalTo: root.view.leadingAnchor, constant: 20), label.trailingAnchor.constraint(equalTo: root.view.trailingAnchor, constant: -20)])
        #endif
        return root
    }

    func updateUIViewController(_ uiViewController: UIViewController, context: Context) {}
}
