import SwiftUI
import Charts

struct ProjectionPoint: Identifiable {
    let id = UUID()
    let date: Date
    let balance: Double
}

class DashboardViewModel: ObservableObject {
    @Published var userName: String = "Alex"
    @Published var currentBalance: Double = 2540.75
    @Published var projectedData: [ProjectionPoint] = []

    init() { generateMockProjection() }

    func generateMockProjection() {
        projectedData.removeAll()
        let now = Date()
        for i in 0..<12 {
            if let d = Calendar.current.date(byAdding: .month, value: i, to: now) {
                projectedData.append(ProjectionPoint(date: d, balance: 2000 + Double(i)*150 + Double.random(in: -80...80)))
            }
        }
    }

    func loadStubIfNeeded() {
        // placeholder for loading stub/core data
        generateMockProjection()
    }
}

struct DashboardView: View {
    @StateObject var vm = DashboardViewModel()
    var body: some View {
        ScrollView {
            VStack(alignment:.leading, spacing:16) {
                HStack {
                    VStack(alignment:.leading) {
                        Text("Hello, \(vm.userName)").font(.headline)
                        Text("Current Balance").font(.subheadline)
                        Text("$\(vm.currentBalance, specifier: "%.2f")").font(.largeTitle).bold()
                    }
                    Spacer()
                    NavigationLink(destination: SettingsView()) {
                        Image("profileIcon").resizable().frame(width:44,height:44).clipShape(Circle())
                    }
                }.padding()

                Chart(vm.projectedData) { p in
                    LineMark(x:.value("Date", p.date), y:.value("Balance", p.balance))
                }.frame(height:220).padding()

                NavigationLink(destination: LinkAccountView()) {
                    HStack { Text("Link a bank account"); Spacer(); Image(systemName:"chevron.right") }
                        .padding().background(Color(UIColor.secondarySystemBackground)).cornerRadius(8).padding(.horizontal)
                }
            }
        }.navigationTitle("Dashboard").onAppear { vm.loadStubIfNeeded() }
    }
}
