FutureBalance - GitHub-ready project skeleton
=============================================

What is included:
- Sources/: SwiftUI source files (Views, ViewModels, Services)
- PlaidServer/: Node.js server (index.js, package.json, .env.example)
- Stub/: server_data.json for local testing
- ASSETS_INSTRUCTIONS.txt: what assets to add to Assets.xcassets
- INSTRUCTIONS.md: how to create an Xcode project and add these files, plus steps to deploy backend and set Codemagic.

IMPORTANT:
- This repo is intended to be uploaded to GitHub. After that:
  1. Create a new Xcode project (App, SwiftUI) locally or in a cloud Mac.
  2. Add the files from Sources/ into the Xcode project (File -> Add Files...). Ensure the app target is checked.
  3. Add Stub/server_data.json to Copy Bundle Resources in Build Phases.
  4. Add Assets as instructed.
  5. Configure Codemagic (or other CI) with this repo to build and upload to TestFlight.
