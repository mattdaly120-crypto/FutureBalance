const express = require('express');
const bodyParser = require('body-parser');
require('dotenv').config();
const app = express();
app.use(bodyParser.json());
const PORT = process.env.PORT || 3000;

app.post('/create_link_token', (req, res) => {
    // In production call Plaid API; here we return a placeholder
    res.json({ link_token: 'SAMPLE_LINK_TOKEN' });
});

app.post('/exchange_public_token', (req, res) => {
    const { public_token } = req.body;
    res.json({ access_token: 'SAMPLE_ACCESS_TOKEN', item_id: 'SAMPLE_ITEM' });
});

app.listen(PORT, () => console.log('Plaid server listening on', PORT));
