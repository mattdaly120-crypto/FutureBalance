Plaid Server Deploy (quick):
1. Push PlaidServer/ to GitHub.
2. On Render.com create a new Web Service, connect the repo.
3. Build command: npm install
4. Start command: node index.js
5. Set environment variables per .env.example in Render dashboard.
